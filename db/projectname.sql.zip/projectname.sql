-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 18 2018 г., 16:23
-- Версия сервера: 5.5.50
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `projectname`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-06-13 20:12:45', '2018-06-13 17:12:45', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://projectname.loc', 'yes'),
(2, 'home', 'http://projectname.loc', 'yes'),
(3, 'blogname', 'Продажа механических клавиатур', 'yes'),
(4, 'blogdescription', 'Сайт по продаже механических клавиатур', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'info@example.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:47:"advanced-custom-field-repeater/acf-repeater.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:22:"cyr3lat/cyr-to-lat.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'projectname', 'yes'),
(41, 'stylesheet', 'projectname', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '8', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'initial_db_version', '38590', 'yes'),
(93, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(94, 'fresh_site', '0', 'yes'),
(95, 'WPLANG', 'ru_RU', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1529327565;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1529341965;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1529342031;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1529342807;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1528912170;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(123, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.6.zip";s:6:"locale";s:5:"ru_RU";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.6.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.6";s:7:"version";s:5:"4.9.6";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1529307842;s:15:"version_checked";s:5:"4.9.6";s:12:"translations";a:0:{}}', 'no'),
(124, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1529307846;s:7:"checked";a:2:{s:11:"projectname";s:3:"1.0";s:15:"twentyseventeen";s:3:"1.6";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(129, 'can_compress_scripts', '1', 'no'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(146, 'acf_version', '4.4.12', 'yes'),
(156, 'new_admin_email', 'info@example.com', 'yes'),
(159, 'current_theme', 'ProjectName', 'yes'),
(160, 'theme_mods_projectname', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(161, 'theme_switched', '', 'yes'),
(205, 'category_children', 'a:0:{}', 'yes'),
(228, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1529185646', 'no'),
(240, '_site_transient_timeout_theme_roots', '1529309645', 'no'),
(241, '_site_transient_theme_roots', 'a:2:{s:11:"projectname";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";}', 'no'),
(242, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1529307847;s:7:"checked";a:5:{s:30:"advanced-custom-fields/acf.php";s:6:"4.4.12";s:47:"advanced-custom-field-repeater/acf-repeater.php";s:5:"1.0.1";s:19:"akismet/akismet.php";s:5:"4.0.3";s:22:"cyr3lat/cyr-to-lat.php";s:3:"3.5";s:9:"hello.php";s:3:"1.7";}s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":12:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"4.0.7";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.4.0.7.zip";s:5:"icons";a:2:{s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";}s:7:"banners";a:1:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.6";s:12:"requires_php";b:0;s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:3:{s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":9:{s:2:"id";s:36:"w.org/plugins/advanced-custom-fields";s:4:"slug";s:22:"advanced-custom-fields";s:6:"plugin";s:30:"advanced-custom-fields/acf.php";s:11:"new_version";s:6:"4.4.12";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:72:"https://downloads.wordpress.org/plugin/advanced-custom-fields.4.4.12.zip";s:5:"icons";a:2:{s:2:"2x";s:75:"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746";s:2:"1x";s:75:"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746";}s:7:"banners";a:2:{s:2:"2x";s:78:"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099";s:2:"1x";s:77:"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102";}s:11:"banners_rtl";a:0:{}}s:22:"cyr3lat/cyr-to-lat.php";O:8:"stdClass":9:{s:2:"id";s:21:"w.org/plugins/cyr3lat";s:4:"slug";s:7:"cyr3lat";s:6:"plugin";s:22:"cyr3lat/cyr-to-lat.php";s:11:"new_version";s:3:"3.5";s:3:"url";s:38:"https://wordpress.org/plugins/cyr3lat/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip";s:5:"icons";a:1:{s:7:"default";s:51:"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg";}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}}s:9:"hello.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";s:5:"icons";a:2:{s:2:"2x";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";s:2:"1x";s:63:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907";}s:7:"banners";a:1:{s:2:"1x";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";}s:11:"banners_rtl";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB AUTO_INCREMENT=570 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 3, '_edit_lock', '1528911621:1'),
(4, 2, '_edit_lock', '1528910124:1'),
(5, 1, '_wp_old_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(8, 8, '_edit_last', '1'),
(9, 8, '_edit_lock', '1529312726:1'),
(10, 8, '_wp_page_template', 'page-home.php'),
(11, 10, '_edit_last', '1'),
(12, 10, '_edit_lock', '1528916660:1'),
(14, 12, '_wp_attached_file', '2018/06/oklick-1.png'),
(15, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:313;s:6:"height";i:107;s:4:"file";s:20:"2018/06/oklick-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"oklick-1-150x107.png";s:5:"width";i:150;s:6:"height";i:107;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"oklick-1-300x103.png";s:5:"width";i:300;s:6:"height";i:103;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 12, '_wp_attachment_image_alt', 'Клавиатура Oklick 180M Black USB'),
(17, 10, '_thumbnail_id', '12'),
(19, 13, '_edit_last', '1'),
(20, 13, '_edit_lock', '1528916751:1'),
(21, 14, '_wp_attached_file', '2018/06/intro-1.png'),
(22, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:293;s:6:"height";i:140;s:4:"file";s:19:"2018/06/intro-1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"intro-1-150x140.png";s:5:"width";i:150;s:6:"height";i:140;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(23, 14, '_wp_attachment_image_alt', 'INTRO KW474B Wireless'),
(24, 13, '_thumbnail_id', '14'),
(26, 17, '_wp_attached_file', '2018/06/oklick-2.png'),
(27, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:284;s:6:"height";i:136;s:4:"file";s:20:"2018/06/oklick-2.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"oklick-2-150x136.png";s:5:"width";i:150;s:6:"height";i:136;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(28, 17, '_wp_attachment_image_alt', 'Игровая клавиатура Oklick 730G'),
(29, 16, '_edit_last', '1'),
(30, 16, '_thumbnail_id', '17'),
(32, 16, '_edit_lock', '1528926156:1'),
(33, 19, '_edit_last', '1'),
(34, 19, 'field_5b22268955bc2', 'a:14:{s:3:"key";s:19:"field_5b22268955bc2";s:5:"label";s:18:"Заголовок";s:4:"name";s:16:"advantages_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(35, 19, 'field_5b2226f855bc3', 'a:13:{s:3:"key";s:19:"field_5b2226f855bc3";s:5:"label";s:12:"Иконки";s:4:"name";s:15:"advantages_list";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:3:{i:0;a:10:{s:3:"key";s:19:"field_5b22279555bc4";s:5:"label";s:35:"Изображение иконки";s:4:"name";s:14:"advantage_icon";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:8:"order_no";i:0;}i:1;a:13:{s:3:"key";s:19:"field_5b2227e355bc5";s:5:"label";s:19:"Заголовок ";s:4:"name";s:15:"advantage_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:8:"order_no";i:1;}i:2;a:10:{s:3:"key";s:19:"field_5b22284355bc6";s:5:"label";s:10:"Текст";s:4:"name";s:14:"advantage_text";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:8:"order_no";i:2;}}s:7:"row_min";s:1:"0";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:42:"Добавить новый элемент";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(37, 19, 'position', 'normal'),
(38, 19, 'layout', 'default'),
(39, 19, 'hide_on_screen', ''),
(40, 19, '_edit_lock', '1529312724:1'),
(43, 20, 'advantages_title', 'Преемущества'),
(44, 20, '_advantages_title', 'field_5b22268955bc2'),
(45, 20, 'advantages_list', '0'),
(46, 20, '_advantages_list', 'field_5b2226f855bc3'),
(47, 8, 'advantages_title', 'Преемущества'),
(48, 8, '_advantages_title', 'field_5b22268955bc2'),
(49, 8, 'advantages_list', '5'),
(50, 8, '_advantages_list', 'field_5b2226f855bc3'),
(51, 21, '_wp_attached_file', '2018/06/icon1.png'),
(52, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:97;s:6:"height";i:97;s:4:"file";s:17:"2018/06/icon1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(53, 21, '_wp_attachment_image_alt', 'Иконка преемущества'),
(54, 22, 'advantages_title', 'Преемущества'),
(55, 22, '_advantages_title', 'field_5b22268955bc2'),
(56, 22, 'advantages_list_0_advantage_icon', '21'),
(57, 22, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(58, 22, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(59, 22, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(60, 22, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(61, 22, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(62, 22, 'advantages_list', '1'),
(63, 22, '_advantages_list', 'field_5b2226f855bc3'),
(64, 8, 'advantages_list_0_advantage_icon', '21'),
(65, 8, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(66, 8, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(67, 8, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(68, 8, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(69, 8, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(70, 1, '_wp_trash_meta_status', 'publish'),
(71, 1, '_wp_trash_meta_time', '1528966382'),
(72, 1, '_wp_desired_post_slug', 'privet-mir'),
(73, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(74, 24, '_wp_attached_file', '2018/06/icon2.png'),
(75, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:97;s:6:"height";i:97;s:4:"file";s:17:"2018/06/icon2.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(76, 24, '_wp_attachment_image_alt', 'Иконка преемуществ 2'),
(77, 25, '_wp_attached_file', '2018/06/icon3.png'),
(78, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:97;s:6:"height";i:97;s:4:"file";s:17:"2018/06/icon3.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(79, 25, '_wp_attachment_image_alt', 'Иконка преемущества 3'),
(80, 26, '_wp_attached_file', '2018/06/icon4.png'),
(81, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:97;s:6:"height";i:97;s:4:"file";s:17:"2018/06/icon4.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(82, 26, '_wp_attachment_image_alt', 'Иконка для преемуществ 4'),
(83, 27, '_wp_attached_file', '2018/06/icon5.png'),
(84, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:97;s:6:"height";i:97;s:4:"file";s:17:"2018/06/icon5.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(85, 27, '_wp_attachment_image_alt', ''),
(86, 28, 'advantages_title', 'Преемущества'),
(87, 28, '_advantages_title', 'field_5b22268955bc2'),
(88, 28, 'advantages_list_0_advantage_icon', '21'),
(89, 28, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(90, 28, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(91, 28, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(92, 28, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(93, 28, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(94, 28, 'advantages_list_1_advantage_icon', '24'),
(95, 28, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(96, 28, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(97, 28, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(98, 28, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(99, 28, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(100, 28, 'advantages_list_2_advantage_icon', '25'),
(101, 28, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(102, 28, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(103, 28, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(104, 28, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(105, 28, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(106, 28, 'advantages_list_3_advantage_icon', '26'),
(107, 28, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(108, 28, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(109, 28, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(110, 28, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(111, 28, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(112, 28, 'advantages_list_4_advantage_icon', '27'),
(113, 28, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(114, 28, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(115, 28, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(116, 28, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(117, 28, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(118, 28, 'advantages_list', '5'),
(119, 28, '_advantages_list', 'field_5b2226f855bc3'),
(120, 8, 'advantages_list_1_advantage_icon', '24'),
(121, 8, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(122, 8, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(123, 8, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(124, 8, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(125, 8, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(126, 8, 'advantages_list_2_advantage_icon', '25'),
(127, 8, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(128, 8, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(129, 8, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(130, 8, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(131, 8, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(132, 8, 'advantages_list_3_advantage_icon', '26'),
(133, 8, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(134, 8, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(135, 8, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(136, 8, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(137, 8, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(138, 8, 'advantages_list_4_advantage_icon', '27'),
(139, 8, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(140, 8, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(141, 8, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(142, 8, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(143, 8, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(144, 29, '_edit_last', '1'),
(145, 29, 'field_5b23cdc714351', 'a:14:{s:3:"key";s:19:"field_5b23cdc714351";s:5:"label";s:18:"Заголовок";s:4:"name";s:11:"about_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(146, 29, 'field_5b23cdd714352', 'a:11:{s:3:"key";s:19:"field_5b23cdd714352";s:5:"label";s:29:"Текстовое после";s:4:"name";s:10:"about_text";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(148, 29, 'position', 'normal'),
(149, 29, 'layout', 'default'),
(150, 29, 'hide_on_screen', ''),
(151, 29, '_edit_lock', '1529312573:1'),
(153, 30, 'about_title', ' О компании'),
(154, 30, '_about_title', 'field_5b23cdc714351'),
(155, 30, 'about_text', ''),
(156, 30, '_about_text', 'field_5b23cdd714352'),
(157, 30, 'advantages_title', 'Преемущества'),
(158, 30, '_advantages_title', 'field_5b22268955bc2'),
(159, 30, 'advantages_list_0_advantage_icon', '21'),
(160, 30, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(161, 30, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(162, 30, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(163, 30, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(164, 30, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(165, 30, 'advantages_list_1_advantage_icon', '24'),
(166, 30, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(167, 30, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(168, 30, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(169, 30, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(170, 30, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(171, 30, 'advantages_list_2_advantage_icon', '25'),
(172, 30, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(173, 30, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(174, 30, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(175, 30, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(176, 30, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(177, 30, 'advantages_list_3_advantage_icon', '26'),
(178, 30, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(179, 30, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(180, 30, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(181, 30, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(182, 30, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(183, 30, 'advantages_list_4_advantage_icon', '27'),
(184, 30, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(185, 30, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(186, 30, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(187, 30, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(188, 30, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(189, 30, 'advantages_list', '5'),
(190, 30, '_advantages_list', 'field_5b2226f855bc3'),
(191, 8, 'about_title', ' О компании'),
(192, 8, '_about_title', 'field_5b23cdc714351'),
(193, 8, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(194, 8, '_about_text', 'field_5b23cdd714352'),
(195, 31, '_wp_attached_file', '2018/06/about-1.jpg'),
(196, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:570;s:6:"height";i:401;s:4:"file";s:19:"2018/06/about-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"about-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"about-1-300x211.jpg";s:5:"width";i:300;s:6:"height";i:211;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(197, 31, '_wp_attachment_image_alt', 'Картинка о нас 1'),
(198, 32, '_wp_attached_file', '2018/06/about-2.jpg'),
(199, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:570;s:6:"height";i:401;s:4:"file";s:19:"2018/06/about-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"about-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"about-2-300x211.jpg";s:5:"width";i:300;s:6:"height";i:211;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(200, 32, '_wp_attachment_image_alt', 'Кртинка о нас 2'),
(201, 33, 'about_title', ' О компании'),
(202, 33, '_about_title', 'field_5b23cdc714351'),
(203, 33, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.'),
(204, 33, '_about_text', 'field_5b23cdd714352'),
(205, 33, 'advantages_title', 'Преемущества'),
(206, 33, '_advantages_title', 'field_5b22268955bc2'),
(207, 33, 'advantages_list_0_advantage_icon', '21'),
(208, 33, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(209, 33, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(210, 33, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(211, 33, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(212, 33, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(213, 33, 'advantages_list_1_advantage_icon', '24'),
(214, 33, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(215, 33, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(216, 33, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(217, 33, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(218, 33, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(219, 33, 'advantages_list_2_advantage_icon', '25'),
(220, 33, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(221, 33, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(222, 33, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(223, 33, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(224, 33, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(225, 33, 'advantages_list_3_advantage_icon', '26'),
(226, 33, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(227, 33, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(228, 33, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(229, 33, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(230, 33, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(231, 33, 'advantages_list_4_advantage_icon', '27'),
(232, 33, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(233, 33, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(234, 33, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(235, 33, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(236, 33, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(237, 33, 'advantages_list', '5'),
(238, 33, '_advantages_list', 'field_5b2226f855bc3'),
(239, 29, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"8";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(240, 34, 'about_title', ' О компании'),
(241, 34, '_about_title', 'field_5b23cdc714351'),
(242, 34, 'about_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.'),
(243, 34, '_about_text', 'field_5b23cdd714352'),
(244, 34, 'advantages_title', 'Преемущества'),
(245, 34, '_advantages_title', 'field_5b22268955bc2'),
(246, 34, 'advantages_list_0_advantage_icon', '21'),
(247, 34, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(248, 34, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(249, 34, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(250, 34, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(251, 34, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(252, 34, 'advantages_list_1_advantage_icon', '24'),
(253, 34, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(254, 34, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(255, 34, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(256, 34, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(257, 34, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(258, 34, 'advantages_list_2_advantage_icon', '25'),
(259, 34, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(260, 34, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(261, 34, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(262, 34, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(263, 34, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(264, 34, 'advantages_list_3_advantage_icon', '26'),
(265, 34, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(266, 34, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(267, 34, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(268, 34, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(269, 34, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(270, 34, 'advantages_list_4_advantage_icon', '27'),
(271, 34, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(272, 34, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(273, 34, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(274, 34, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(275, 34, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(276, 34, 'advantages_list', '5'),
(277, 34, '_advantages_list', 'field_5b2226f855bc3'),
(278, 35, 'about_title', ' О компании'),
(279, 35, '_about_title', 'field_5b23cdc714351'),
(280, 35, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.'),
(281, 35, '_about_text', 'field_5b23cdd714352'),
(282, 35, 'advantages_title', 'Преемущества'),
(283, 35, '_advantages_title', 'field_5b22268955bc2'),
(284, 35, 'advantages_list_0_advantage_icon', '21'),
(285, 35, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(286, 35, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(287, 35, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(288, 35, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(289, 35, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(290, 35, 'advantages_list_1_advantage_icon', '24'),
(291, 35, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(292, 35, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(293, 35, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(294, 35, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(295, 35, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(296, 35, 'advantages_list_2_advantage_icon', '25'),
(297, 35, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(298, 35, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(299, 35, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(300, 35, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(301, 35, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(302, 35, 'advantages_list_3_advantage_icon', '26'),
(303, 35, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(304, 35, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(305, 35, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(306, 35, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(307, 35, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(308, 35, 'advantages_list_4_advantage_icon', '27'),
(309, 35, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(310, 35, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(311, 35, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(312, 35, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(313, 35, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(314, 35, 'advantages_list', '5'),
(315, 35, '_advantages_list', 'field_5b2226f855bc3'),
(316, 36, 'about_title', ' О компании'),
(317, 36, '_about_title', 'field_5b23cdc714351'),
(318, 36, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(319, 36, '_about_text', 'field_5b23cdd714352'),
(320, 36, 'advantages_title', 'Преемущества'),
(321, 36, '_advantages_title', 'field_5b22268955bc2'),
(322, 36, 'advantages_list_0_advantage_icon', '21'),
(323, 36, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(324, 36, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(325, 36, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(326, 36, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(327, 36, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(328, 36, 'advantages_list_1_advantage_icon', '24'),
(329, 36, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(330, 36, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(331, 36, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(332, 36, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(333, 36, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(334, 36, 'advantages_list_2_advantage_icon', '25'),
(335, 36, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(336, 36, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(337, 36, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(338, 36, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(339, 36, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(340, 36, 'advantages_list_3_advantage_icon', '26'),
(341, 36, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(342, 36, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(343, 36, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(344, 36, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(345, 36, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(346, 36, 'advantages_list_4_advantage_icon', '27'),
(347, 36, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(348, 36, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(349, 36, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(350, 36, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(351, 36, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(352, 36, 'advantages_list', '5'),
(353, 36, '_advantages_list', 'field_5b2226f855bc3'),
(354, 37, '_edit_last', '1'),
(355, 37, '_edit_lock', '1529096843:1'),
(358, 39, '_wp_attached_file', '2018/06/keyboard-4.png'),
(359, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:282;s:6:"height";i:127;s:4:"file";s:22:"2018/06/keyboard-4.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"keyboard-4-150x127.png";s:5:"width";i:150;s:6:"height";i:127;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(360, 39, '_wp_attachment_image_alt', 'Клавиатура Logitech Wireless Keyboard K360'),
(361, 37, '_thumbnail_id', '39'),
(362, 41, '_edit_last', '1'),
(363, 41, 'field_5b24dcd319280', 'a:14:{s:3:"key";s:19:"field_5b24dcd319280";s:5:"label";s:12:"Широта";s:4:"name";s:7:"map_lat";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(364, 41, 'field_5b24dd0719281', 'a:14:{s:3:"key";s:19:"field_5b24dd0719281";s:5:"label";s:14:"Долгота";s:4:"name";s:7:"map_lng";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(365, 41, 'field_5b24dd1a19282', 'a:14:{s:3:"key";s:19:"field_5b24dd1a19282";s:5:"label";s:12:"Маштаб";s:4:"name";s:9:"map_scale";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(366, 41, 'field_5b24dd3f19283', 'a:11:{s:3:"key";s:19:"field_5b24dd3f19283";s:5:"label";s:23:"Иконка метки";s:4:"name";s:8:"map_icon";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(368, 41, 'position', 'normal'),
(369, 41, 'layout', 'default'),
(370, 41, 'hide_on_screen', ''),
(371, 41, '_edit_lock', '1529312566:1'),
(373, 42, '_wp_attached_file', '2018/06/placemark.png'),
(374, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:51;s:6:"height";i:73;s:4:"file";s:21:"2018/06/placemark.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(375, 42, '_wp_attachment_image_alt', 'Метка на карте'),
(376, 43, 'map_lat', '52.2151874'),
(377, 43, '_map_lat', 'field_5b24dcd319280'),
(378, 43, 'map_lng', '20.9598662'),
(379, 43, '_map_lng', 'field_5b24dd0719281'),
(380, 43, 'map_scale', '16'),
(381, 43, '_map_scale', 'field_5b24dd1a19282'),
(382, 43, 'map_icon', '42'),
(383, 43, '_map_icon', 'field_5b24dd3f19283'),
(384, 43, 'about_title', ' О компании'),
(385, 43, '_about_title', 'field_5b23cdc714351'),
(386, 43, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(387, 43, '_about_text', 'field_5b23cdd714352'),
(388, 43, 'advantages_title', 'Преемущества'),
(389, 43, '_advantages_title', 'field_5b22268955bc2'),
(390, 43, 'advantages_list_0_advantage_icon', '21'),
(391, 43, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(392, 43, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(393, 43, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(394, 43, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(395, 43, '_advantages_list_0_advantage_text', 'field_5b22284355bc6');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(396, 43, 'advantages_list_1_advantage_icon', '24'),
(397, 43, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(398, 43, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(399, 43, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(400, 43, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(401, 43, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(402, 43, 'advantages_list_2_advantage_icon', '25'),
(403, 43, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(404, 43, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(405, 43, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(406, 43, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(407, 43, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(408, 43, 'advantages_list_3_advantage_icon', '26'),
(409, 43, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(410, 43, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(411, 43, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(412, 43, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(413, 43, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(414, 43, 'advantages_list_4_advantage_icon', '27'),
(415, 43, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(416, 43, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(417, 43, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(418, 43, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(419, 43, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(420, 43, 'advantages_list', '5'),
(421, 43, '_advantages_list', 'field_5b2226f855bc3'),
(422, 8, 'map_lat', '52.2151874'),
(423, 8, '_map_lat', 'field_5b24dcd319280'),
(424, 8, 'map_lng', '20.9598662'),
(425, 8, '_map_lng', 'field_5b24dd0719281'),
(426, 8, 'map_scale', '16'),
(427, 8, '_map_scale', 'field_5b24dd1a19282'),
(428, 8, 'map_icon', '42'),
(429, 8, '_map_icon', 'field_5b24dd3f19283'),
(430, 44, 'map_lat', ''),
(431, 44, '_map_lat', 'field_5b24dcd319280'),
(432, 44, 'map_lng', ''),
(433, 44, '_map_lng', 'field_5b24dd0719281'),
(434, 44, 'map_scale', '1'),
(435, 44, '_map_scale', 'field_5b24dd1a19282'),
(436, 44, 'map_icon', '42'),
(437, 44, '_map_icon', 'field_5b24dd3f19283'),
(438, 44, 'about_title', ' О компании'),
(439, 44, '_about_title', 'field_5b23cdc714351'),
(440, 44, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(441, 44, '_about_text', 'field_5b23cdd714352'),
(442, 44, 'advantages_title', 'Преемущества'),
(443, 44, '_advantages_title', 'field_5b22268955bc2'),
(444, 44, 'advantages_list_0_advantage_icon', '21'),
(445, 44, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(446, 44, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(447, 44, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(448, 44, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(449, 44, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(450, 44, 'advantages_list_1_advantage_icon', '24'),
(451, 44, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(452, 44, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(453, 44, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(454, 44, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(455, 44, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(456, 44, 'advantages_list_2_advantage_icon', '25'),
(457, 44, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(458, 44, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(459, 44, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(460, 44, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(461, 44, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(462, 44, 'advantages_list_3_advantage_icon', '26'),
(463, 44, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(464, 44, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(465, 44, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(466, 44, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(467, 44, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(468, 44, 'advantages_list_4_advantage_icon', '27'),
(469, 44, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(470, 44, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(471, 44, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(472, 44, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(473, 44, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(474, 44, 'advantages_list', '5'),
(475, 44, '_advantages_list', 'field_5b2226f855bc3'),
(476, 45, 'map_lat', '52.2151874'),
(477, 45, '_map_lat', 'field_5b24dcd319280'),
(478, 45, 'map_lng', '20.9598662'),
(479, 45, '_map_lng', 'field_5b24dd0719281'),
(480, 45, 'map_scale', '1'),
(481, 45, '_map_scale', 'field_5b24dd1a19282'),
(482, 45, 'map_icon', '42'),
(483, 45, '_map_icon', 'field_5b24dd3f19283'),
(484, 45, 'about_title', ' О компании'),
(485, 45, '_about_title', 'field_5b23cdc714351'),
(486, 45, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(487, 45, '_about_text', 'field_5b23cdd714352'),
(488, 45, 'advantages_title', 'Преемущества'),
(489, 45, '_advantages_title', 'field_5b22268955bc2'),
(490, 45, 'advantages_list_0_advantage_icon', '21'),
(491, 45, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(492, 45, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(493, 45, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(494, 45, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(495, 45, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(496, 45, 'advantages_list_1_advantage_icon', '24'),
(497, 45, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(498, 45, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(499, 45, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(500, 45, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(501, 45, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(502, 45, 'advantages_list_2_advantage_icon', '25'),
(503, 45, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(504, 45, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(505, 45, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(506, 45, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(507, 45, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(508, 45, 'advantages_list_3_advantage_icon', '26'),
(509, 45, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(510, 45, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(511, 45, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(512, 45, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(513, 45, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(514, 45, 'advantages_list_4_advantage_icon', '27'),
(515, 45, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(516, 45, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(517, 45, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(518, 45, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(519, 45, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(520, 45, 'advantages_list', '5'),
(521, 45, '_advantages_list', 'field_5b2226f855bc3'),
(522, 46, 'map_lat', '52.2151874'),
(523, 46, '_map_lat', 'field_5b24dcd319280'),
(524, 46, 'map_lng', '20.9598662'),
(525, 46, '_map_lng', 'field_5b24dd0719281'),
(526, 46, 'map_scale', '16'),
(527, 46, '_map_scale', 'field_5b24dd1a19282'),
(528, 46, 'map_icon', '42'),
(529, 46, '_map_icon', 'field_5b24dd3f19283'),
(530, 46, 'about_title', ' О компании'),
(531, 46, '_about_title', 'field_5b23cdc714351'),
(532, 46, 'about_text', '<img class="alignnone size-medium wp-image-31" src="http://projectname.loc/wp-content/uploads/2018/06/about-1-300x211.jpg" alt="Картинка о нас 1" width="300" height="211" />\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами\r\nLorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\nLorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.\r\nВ то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно\r\nпережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem\r\nIpsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n\r\n<img class="alignnone size-medium wp-image-32" src="http://projectname.loc/wp-content/uploads/2018/06/about-2-300x211.jpg" alt="Кртинка о нас 2" width="300" height="211" />'),
(533, 46, '_about_text', 'field_5b23cdd714352'),
(534, 46, 'advantages_title', 'Преемущества'),
(535, 46, '_advantages_title', 'field_5b22268955bc2'),
(536, 46, 'advantages_list_0_advantage_icon', '21'),
(537, 46, '_advantages_list_0_advantage_icon', 'field_5b22279555bc4'),
(538, 46, 'advantages_list_0_advantage_title', 'Заголовок 1'),
(539, 46, '_advantages_list_0_advantage_title', 'field_5b2227e355bc5'),
(540, 46, 'advantages_list_0_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(541, 46, '_advantages_list_0_advantage_text', 'field_5b22284355bc6'),
(542, 46, 'advantages_list_1_advantage_icon', '24'),
(543, 46, '_advantages_list_1_advantage_icon', 'field_5b22279555bc4'),
(544, 46, 'advantages_list_1_advantage_title', 'Заголовок 2'),
(545, 46, '_advantages_list_1_advantage_title', 'field_5b2227e355bc5'),
(546, 46, 'advantages_list_1_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(547, 46, '_advantages_list_1_advantage_text', 'field_5b22284355bc6'),
(548, 46, 'advantages_list_2_advantage_icon', '25'),
(549, 46, '_advantages_list_2_advantage_icon', 'field_5b22279555bc4'),
(550, 46, 'advantages_list_2_advantage_title', 'Заголовок 3'),
(551, 46, '_advantages_list_2_advantage_title', 'field_5b2227e355bc5'),
(552, 46, 'advantages_list_2_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(553, 46, '_advantages_list_2_advantage_text', 'field_5b22284355bc6'),
(554, 46, 'advantages_list_3_advantage_icon', '26'),
(555, 46, '_advantages_list_3_advantage_icon', 'field_5b22279555bc4'),
(556, 46, 'advantages_list_3_advantage_title', 'Заголовок 4'),
(557, 46, '_advantages_list_3_advantage_title', 'field_5b2227e355bc5'),
(558, 46, 'advantages_list_3_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(559, 46, '_advantages_list_3_advantage_text', 'field_5b22284355bc6'),
(560, 46, 'advantages_list_4_advantage_icon', '27'),
(561, 46, '_advantages_list_4_advantage_icon', 'field_5b22279555bc4'),
(562, 46, 'advantages_list_4_advantage_title', 'Заголовок 5'),
(563, 46, '_advantages_list_4_advantage_title', 'field_5b2227e355bc5'),
(564, 46, 'advantages_list_4_advantage_text', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem Ipsum. вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с Lorem'),
(565, 46, '_advantages_list_4_advantage_text', 'field_5b22284355bc6'),
(566, 46, 'advantages_list', '5'),
(567, 46, '_advantages_list', 'field_5b2226f855bc3'),
(568, 41, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"8";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(569, 19, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"8";s:8:"order_no";i:0;s:8:"group_no";i:0;}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-06-13 20:12:45', '2018-06-13 17:12:45', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'trash', 'open', 'open', '', 'privet-mir__trashed', '', '', '2018-06-14 11:53:02', '2018-06-14 08:53:02', '', 0, 'http://projectname.loc/?p=1', 0, 'post', '', 1),
(2, 1, '2018-06-13 20:12:45', '2018-06-13 17:12:45', 'Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:\n\n<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>\n\n...или так:\n\n<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>\n\nПерейдите <a href="http://projectname.loc/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-06-13 20:12:45', '2018-06-13 17:12:45', '', 0, 'http://projectname.loc/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-06-13 20:12:45', '2018-06-13 17:12:45', '<h2>Кто мы</h2><p>Наш адрес сайта: http://projectname.loc.</p><h2>Какие персональные данные мы собираем и с какой целью</h2><h3>Комментарии</h3><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><h3>Медиафайлы</h3><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><h3>Формы контактов</h3><h3>Куки</h3><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><h3>Встраиваемое содержимое других вебсайтов</h3><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><p>Эти сайты могут собирать ваши данные, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взвимодействия если у вас есть учетная запись и вы авторизовались на том сайте.</p><h3>Веб-аналитика</h3><h2>С кем мы делимся вашими данными</h2><h2>Как долго мы храним ваши данные</h2><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><h2>Какие у вас права на ваши данные</h2><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><h2>Куда мы отправляем ваши данные</h2><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><h2>Ваша контактная информация</h2><h2>Дополнительная информация</h2><h3>Как мы защищаем ваши данные</h3><h3>Какие принимаются процедуры против взлома данных</h3><h3>От каких третьих сторон мы получаем данные</h3><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><h3>Требования к раскрытию отраслевых нормативных требований</h3>', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-06-13 20:12:45', '2018-06-13 17:12:45', '', 0, 'http://projectname.loc/?page_id=3', 0, 'page', '', 0),
(4, 1, '2018-06-13 20:13:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-06-13 20:13:52', '0000-00-00 00:00:00', '', 0, 'http://projectname.loc/?p=4', 0, 'post', '', 0),
(6, 1, '2018-06-13 20:26:47', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-06-13 20:26:47', '0000-00-00 00:00:00', '', 0, 'http://projectname.loc/?post_type=acf&p=6', 0, 'acf', '', 0),
(7, 1, '2018-06-13 20:29:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-06-13 20:29:41', '0000-00-00 00:00:00', '', 0, 'http://projectname.loc/?page_id=7', 0, 'page', '', 0),
(8, 1, '2018-06-13 20:49:47', '2018-06-13 17:49:47', 'Это главная страница', 'Главная страница', '', 'publish', 'closed', 'closed', '', 'glavnaya-stranitsa', '', '', '2018-06-16 12:57:40', '2018-06-16 09:57:40', '', 0, 'http://projectname.loc/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-06-13 20:37:50', '2018-06-13 17:37:50', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-13 20:37:50', '2018-06-13 17:37:50', '', 8, 'http://projectname.loc/2018/06/13/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-06-13 22:04:49', '2018-06-13 19:04:49', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Клавиатура Oklick 180M Black USB', '', 'publish', 'open', 'open', '', 'klaviatura-oklick-180m-black-usb', '', '', '2018-06-13 22:06:33', '2018-06-13 19:06:33', '', 0, 'http://projectname.loc/?p=10', 0, 'post', '', 0),
(11, 1, '2018-06-13 22:04:49', '2018-06-13 19:04:49', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Клавиатура Oklick 180M Black USB', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-06-13 22:04:49', '2018-06-13 19:04:49', '', 10, 'http://projectname.loc/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-06-13 22:06:14', '2018-06-13 19:06:14', 'Клавиатура Oklick 180M Black USB', 'Клавиатура Oklick 180M Black USB', '', 'inherit', 'open', 'closed', '', 'oklick-1', '', '', '2018-06-13 22:06:31', '2018-06-13 19:06:31', '', 10, 'http://projectname.loc/wp-content/uploads/2018/06/oklick-1.png', 0, 'attachment', 'image/png', 0),
(13, 1, '2018-06-13 22:08:02', '2018-06-13 19:08:02', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'INTRO KW474B Wireless', '', 'publish', 'open', 'open', '', 'intro-kw474b-wireless', '', '', '2018-06-13 22:08:02', '2018-06-13 19:08:02', '', 0, 'http://projectname.loc/?p=13', 0, 'post', '', 0),
(14, 1, '2018-06-13 22:07:46', '2018-06-13 19:07:46', 'INTRO KW474B Wireless', 'INTRO KW474B Wireless', '', 'inherit', 'open', 'closed', '', 'intro-1', '', '', '2018-06-13 22:08:01', '2018-06-13 19:08:01', '', 13, 'http://projectname.loc/wp-content/uploads/2018/06/intro-1.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2018-06-13 22:08:02', '2018-06-13 19:08:02', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'INTRO KW474B Wireless', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-06-13 22:08:02', '2018-06-13 19:08:02', '', 13, 'http://projectname.loc/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-06-13 22:09:08', '2018-06-13 19:09:08', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Игровая клавиатура Oklick 730G', '', 'publish', 'open', 'open', '', 'igrovaya-klaviatura-oklick-730g', '', '', '2018-06-13 22:09:08', '2018-06-13 19:09:08', '', 0, 'http://projectname.loc/?p=16', 0, 'post', '', 0),
(17, 1, '2018-06-13 22:08:53', '2018-06-13 19:08:53', 'Игровая клавиатура Oklick 730G', 'Игровая клавиатура Oklick 730G', '', 'inherit', 'open', 'closed', '', 'oklick-2', '', '', '2018-06-13 22:09:06', '2018-06-13 19:09:06', '', 16, 'http://projectname.loc/wp-content/uploads/2018/06/oklick-2.png', 0, 'attachment', 'image/png', 0),
(18, 1, '2018-06-13 22:09:08', '2018-06-13 19:09:08', 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Игровая клавиатура Oklick 730G', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-06-13 22:09:08', '2018-06-13 19:09:08', '', 16, 'http://projectname.loc/16-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-06-14 11:33:45', '2018-06-14 08:33:45', '', 'Секция преемущества', '', 'publish', 'closed', 'closed', '', 'acf_sektsiya-preemushhestva', '', '', '2018-06-18 12:05:23', '2018-06-18 09:05:23', '', 0, 'http://projectname.loc/?post_type=acf&#038;p=19', 1, 'acf', '', 0),
(20, 1, '2018-06-14 11:35:31', '2018-06-14 08:35:31', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-14 11:35:31', '2018-06-14 08:35:31', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2018-06-14 11:49:51', '2018-06-14 08:49:51', 'Иконка преемущества', 'Иконка преемущества', '', 'inherit', 'open', 'closed', '', 'icon1', '', '', '2018-06-14 11:50:56', '2018-06-14 08:50:56', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/icon1.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2018-06-14 11:51:06', '2018-06-14 08:51:06', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-14 11:51:06', '2018-06-14 08:51:06', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2018-06-14 11:53:02', '2018-06-14 08:53:02', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-06-14 11:53:02', '2018-06-14 08:53:02', '', 1, 'http://projectname.loc/1-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2018-06-14 11:53:33', '2018-06-14 08:53:33', 'Иконка преемуществ 2', 'Иконка преемуществ 2', '', 'inherit', 'open', 'closed', '', 'icon2', '', '', '2018-06-14 11:53:52', '2018-06-14 08:53:52', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/icon2.png', 0, 'attachment', 'image/png', 0),
(25, 1, '2018-06-14 11:54:06', '2018-06-14 08:54:06', 'Иконка преемущества 3', 'Иконка преемущества 3', '', 'inherit', 'open', 'closed', '', 'icon3', '', '', '2018-06-14 11:54:21', '2018-06-14 08:54:21', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/icon3.png', 0, 'attachment', 'image/png', 0),
(26, 1, '2018-06-14 11:54:40', '2018-06-14 08:54:40', 'Иконка для преемуществ 4', 'icon4', '', 'inherit', 'open', 'closed', '', 'icon4', '', '', '2018-06-14 11:54:56', '2018-06-14 08:54:56', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/icon4.png', 0, 'attachment', 'image/png', 0),
(27, 1, '2018-06-14 11:55:18', '2018-06-14 08:55:18', '', 'Иконка преемущества 5', '', 'inherit', 'open', 'closed', '', 'icon5', '', '', '2018-06-14 11:55:28', '2018-06-14 08:55:28', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/icon5.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2018-06-14 11:55:32', '2018-06-14 08:55:32', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-14 11:55:32', '2018-06-14 08:55:32', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2018-06-15 17:32:19', '2018-06-15 14:32:19', '', 'Секция о нас', '', 'publish', 'closed', 'closed', '', 'acf_sektsiya-o-nas', '', '', '2018-06-15 17:38:19', '2018-06-15 14:38:19', '', 0, 'http://projectname.loc/?post_type=acf&#038;p=29', 0, 'acf', '', 0),
(30, 1, '2018-06-15 17:33:00', '2018-06-15 14:33:00', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-15 17:33:00', '2018-06-15 14:33:00', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2018-06-15 17:33:58', '2018-06-15 14:33:58', 'Картинка о нас 1', 'Картинка о нас 1', '', 'inherit', 'open', 'closed', '', 'about-1', '', '', '2018-06-15 17:34:10', '2018-06-15 14:34:10', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/about-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2018-06-15 17:34:56', '2018-06-15 14:34:56', 'Кртинка о нас 2', 'Кртинка о нас 2', '', 'inherit', 'open', 'closed', '', 'about-2', '', '', '2018-06-15 17:35:05', '2018-06-15 14:35:05', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/about-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2018-06-15 17:35:23', '2018-06-15 14:35:23', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-15 17:35:23', '2018-06-15 14:35:23', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2018-06-15 17:38:43', '2018-06-15 14:38:43', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-15 17:38:43', '2018-06-15 14:38:43', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2018-06-15 17:39:35', '2018-06-15 14:39:35', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-15 17:39:35', '2018-06-15 14:39:35', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2018-06-15 17:42:42', '2018-06-15 14:42:42', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-15 17:42:42', '2018-06-15 14:42:42', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-06-15 17:53:46', '2018-06-15 14:53:46', 'Lorem Ipsum — это текст-«рыба», часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной «рыбой» для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Клавиатура Logitech K360', '', 'publish', 'open', 'open', '', 'klaviatura-logitech-wireless-keyboard-k360', '', '', '2018-06-15 17:56:03', '2018-06-15 14:56:03', '', 0, 'http://projectname.loc/?p=37', 0, 'post', '', 0),
(38, 1, '2018-06-15 17:53:46', '2018-06-15 14:53:46', 'Lorem Ipsum — это текст-«рыба», часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной «рыбой» для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Клавиатура Logitech Wireless Keyboard K360', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-06-15 17:53:46', '2018-06-15 14:53:46', '', 37, 'http://projectname.loc/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-06-15 17:54:59', '2018-06-15 14:54:59', 'Клавиатура Logitech Wireless Keyboard K360', 'keyboard-4', '', 'inherit', 'open', 'closed', '', 'keyboard-4', '', '', '2018-06-15 17:55:14', '2018-06-15 14:55:14', '', 37, 'http://projectname.loc/wp-content/uploads/2018/06/keyboard-4.png', 0, 'attachment', 'image/png', 0),
(40, 1, '2018-06-15 17:56:03', '2018-06-15 14:56:03', 'Lorem Ipsum — это текст-«рыба», часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной «рыбой» для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для', 'Клавиатура Logitech K360', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-06-15 17:56:03', '2018-06-15 14:56:03', '', 37, 'http://projectname.loc/37-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-06-16 12:50:31', '2018-06-16 09:50:31', '', 'Карта', '', 'publish', 'closed', 'closed', '', 'acf_karta', '', '', '2018-06-18 12:05:07', '2018-06-18 09:05:07', '', 0, 'http://projectname.loc/?post_type=acf&#038;p=41', 3, 'acf', '', 0),
(42, 1, '2018-06-16 12:52:20', '2018-06-16 09:52:20', 'Метка на карте', 'Метка на карте', '', 'inherit', 'open', 'closed', '', 'placemark', '', '', '2018-06-16 12:52:31', '2018-06-16 09:52:31', '', 8, 'http://projectname.loc/wp-content/uploads/2018/06/placemark.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2018-06-16 12:52:34', '2018-06-16 09:52:34', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-16 12:52:34', '2018-06-16 09:52:34', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2018-06-16 12:57:10', '2018-06-16 09:57:10', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-16 12:57:10', '2018-06-16 09:57:10', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-06-16 12:57:26', '2018-06-16 09:57:26', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-16 12:57:26', '2018-06-16 09:57:26', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-06-16 12:57:40', '2018-06-16 09:57:40', 'Это главная страница', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-06-16 12:57:40', '2018-06-16 09:57:40', '', 8, 'http://projectname.loc/8-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', 'bez-rubriki', 0),
(2, 'Oklick', 'oklick', 0),
(3, 'Intro', 'intro', 0),
(4, 'Logitech', 'logitech', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 2, 0),
(13, 3, 0),
(16, 2, 0),
(37, 4, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', 'Клавиатуры марки Oklick', 0, 2),
(3, 3, 'category', 'Клавиатуры Intro', 0, 1),
(4, 4, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'test'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"89073a627e73d9b9475fd07b55230a1c18b411902f0822bf485fc3d4410c1ad0";a:4:{s:10:"expiration";i:1530119630;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:77:"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0";s:5:"login";i:1528910030;}s:64:"c9824d5f914f121868a8c152ea3d83f532e3184e323ca096e9b366441b4abe61";a:4:{s:10:"expiration";i:1529084609;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:77:"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0";s:5:"login";i:1528911809;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'closedpostboxes_acf', 'a:0:{}'),
(20, 1, 'metaboxhidden_acf', 'a:1:{i:0;s:7:"slugdiv";}'),
(21, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse&hidetb=0'),
(22, 1, 'wp_user-settings-time', '1529073259'),
(23, 1, 'closedpostboxes_page', 'a:0:{}'),
(24, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'test', '$P$BJ9IFZ2jFHhaOWiiAn4m52ks4HfejL/', 'test', 'info@example.com', '', '2018-06-13 17:12:45', '', 0, 'test');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Индексы таблицы `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Индексы таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT для таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=570;
--
-- AUTO_INCREMENT для таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT для таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT для таблицы `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
